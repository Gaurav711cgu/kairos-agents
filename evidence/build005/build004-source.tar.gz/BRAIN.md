# Kairos working brain

Updated 2026-10-12. **Build004 local engineering handoff ready; capacity targets passed, repair target missed.** Start `docs/FINAL_REPORT_004.md`; detailed chronological work remains in `docs/BUILD_004.md`. Repository `/Users/gauravkumarnayak/Desktop/new-karos` requires escalated writes. User-facing style defaults to caveman; persisted documentation uses normal English. No paid API, hardware purchase, public hosting, commit, push or reset.

## Current result

- Full backend: 213 passed, two opt-in skips, two dependency warnings. Both real model/container opt-in checks passed separately.
- Frontend: seven client/boundary tests, lint/types/production build, eleven fixture browser journeys and three real OIDC journeys passed. Final real production inspection passed desktop/390px, keyboard, downloads, comparison, capacity history and unavailable records. Screenshots under `evidence/build004/`.
- Both SIGKILL drills passed with zero recovery dispatches. Consistent restore verified 109 investigations, 1,145 objects and 1,546 references. Earned build003 model patch reproduced with 110 tests and one skip. Non-root API/web images passed all eighteen smoke checks. Current dependency audits report no known findings.
- Complete 42-minute follow-up: 435,270 HTTP requests, zero errors/429s, all local targets passed. Soak 272,855 requests, acknowledgement p95 275.19ms/read p95 16.79ms. Original mixed-workload soak failed; interrupted quieter repeat remains preserved. Kairos workloads stayed stopped; a separate-project build finished before measurement; other shared-host activity was not exhaustively measured. See `docs/CAPACITY_004.md` and `capacity-summary-final.json`.
- All eighteen new real cases qualified before models: six development/twelve locked evaluation. Frozen three-strategy evaluation complete: 36 attempts, zero verified repairs; all 78 development/evaluation attempts preserved. Quality target six cases/two repositories missed. No evaluation retuning or replacement attempts.
- Build003 remains separate: two verified attempts on one distinct Django case, same case solved by single call and loop; no loop advantage. Archive 170 sources/72 historical evidence fingerprints verified; historical images retained.

## Code map

- `kairos_api/investigations/`: routes, PostgreSQL receipts/progress/pagination/quotas, registry, fenced worker, v4 context/actions/edits and disposable verification. Agent modules frozen for this study; do not rewrite old configurations.
- `dashboard/hooks/useInvestigationWorkbench.ts`, `lib/investigation-client.ts`: read cancellation/generations, command journal and progress polling. Shared inspector renders readable evidence privately/publicly. Comparisons prefilter case IDs, retain fingerprint checks and bound reads to four.
- `scripts/start_local004.py`: prepared API/web launch; `--without-inference` uses saved evidence. Inference launch checks exact registered images first. `scripts/recover_verifier004.py` restores the exact historical pytest executable image from local BuildKit blobs; optional provenance attachment was missing and is disclosed.
- `scripts/benchmark_control_plane.py`, `report_capacity004.py`: isolated fixture HTTP/PG measurement and original-plus-repeat report. New runs require new directories.
- `scripts/qualify_study004.py`, `study004.py`, `present_study004.py`: deterministic qualification, bounded development/frozen evaluation and presentation. Do not rerun evaluation for a better score. Old setup/evaluate/seal scripts write build003; do not rerun unmodified.
- `scripts/seal_advancement_evidence.py`: current working-tree/evidence inventory; hashes establish local consistency, not signed immutability.

## Operation and bounds

Mac web3100/API8100/PG55432/Keycloak8088/model8130. Website/API/inference and unused Docker stopped after handoff. Open Docker only when required; separate inference, builds, browser and capacity phases on 8 GB Mac. Preserve volumes and tagged images. Lenovo Windows8GB/RTX3050 4GB setup remains untested without machine access. Runtime currently 4,847,943,680 bytes; free space 34,560,233,472 bytes; 6GiB runtime/4GiB reserve guards passed. Shared Docker/cache installed footprints are not exact release additions. Never print `.env.kairos.local` or private identity/session captures.

One execution globally; 24 queued/running; tenant 6. Loop six calls/two applied candidates/two checks/600 seconds. No arbitrary shell, runtime network, credentials or socket in disposable verifier. Candidate Python shares verifier environment: adversarial test forgery is unproven.

## Evidence limits

Rebooted Django 11095 drafts became timeout through expired DB-clock recovery; Requests 1142 drafts retained an uncertain fourth dispatch as unknown. Zero redispatch; their duration incomplete and unknown consumption not zero. Context overflow and unavailable verifier image remain infrastructure failures. Exact image recovered and baseline/reference rechecked without changing agent outcomes.

Public historical cases may be in training and source regions were human-localized. 0/36 supports no broad repair or superiority claim. Local load, restore and hashes support no production-scale/availability/offsite/immutable-history claim. Candidate mock defense/debugging and personal ownership remain unassessed; use `docs/INTERVIEW_DEFENSE.md`. Public hosting, outside adoption, hosted CI and model research remain separate milestones.
