import { defineConfig } from '@playwright/test';
export default defineConfig({
  testDir:'./e2e',testIgnore:'identity.spec.ts',workers:1,timeout:30000,reporter:[['list']],
  use:{baseURL:'http://127.0.0.1:3104',viewport:{width:1440,height:1000},trace:'off'},
  outputDir:'.playwright-results',
  webServer:[
    {command:'cd .. && .venv/bin/python scripts/browser_fixture.py',url:'http://127.0.0.1:8195/docs',reuseExistingServer:true},
    {command:'KAIROS_API_URL=http://127.0.0.1:8195 npm run dev -- --hostname 127.0.0.1 --port 3104',url:'http://127.0.0.1:3104/workbench',reuseExistingServer:true,timeout:120000},
  ],
});
