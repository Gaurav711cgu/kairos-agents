# Kairos

A local full-stack workbench for investigating repository defects, inspecting proposed repairs and reproducing the checks.

Start with a real, earned result: [Django #10914](https://github.com/django/django/pull/10914). A recorded local-model candidate changes uploaded-file permissions from `None` to `0o644`. Independent checks ran 110 tests with one upstream skip. Open `/investigations/8b03a42f-149e-4d44-937f-0d61636f6042` for the source, before/after diff, captured context, check output and downloadable patch. This is the preserved build003 repair; newer results are reported separately.

## Reproduce that repair

From this prepared installation, with Docker running:

```bash
PYTHONPATH=. .venv/bin/python scripts/reproduce_investigation.py --record evidence/build003/django__django-10914-baseline-v3.json --output /tmp/kairos-repair.json
```

The command verifies frozen material, applies the recorded model patch in a disposable source copy and runs registered checks without runtime network. It needs no account, database, live inference or paid API. Reference repairs never count as model results.

## Inspect the local website

After installing the locked Python and Node dependencies, provisioning local identity and preparing the frozen cases, build the website once:

```bash
KAIROS_NEXT_BUILD_DIR=.next-build npm --prefix dashboard run build
```

Open Docker only when the database or disposable checks need it. On the prepared Mac, start saved-evidence inspection:

```bash
PYTHONPATH=. .venv/bin/python -m scripts.start_local004 --without-inference
```

Open `http://127.0.0.1:3100`. Public evidence needs no login. Private commands use Keycloak OIDC, database membership and role checks. Ctrl-C stops launcher-owned processes. To execute investigations, omit `--without-inference`; the launcher uses the selected pinned local model. Run inference, builds and capacity tests separately on the 8GB Mac. Stop Docker when it is unused; preserve its volumes and historical images.

Fresh-machine preparation and image provenance are documented in [the preserved build003 setup](docs/README_BUILD_003.md) and [identity setup](infra/identity/README.md). Those older preparation scripts write historical material: do not rerun them over this installation or retag its frozen build002/003 images. A rebuilt environment must be recorded as a provenance change. Build004 study preparation uses separate scripts and manifests. The optional Windows inference recipe is untested without the Lenovo; no remote hardware result is claimed.

## What has engineering depth

- A focused client transport and state hook prevent late responses from overwriting a newer investigation. Create/fork commands retain workspace-scoped identities across reloads and uncertain acknowledgements.
- Authenticated progress summaries, integrity-checked downloads, stable cursor pagination, additive indexes and explicit quotas support the real workbench. One investigation executes globally; at most 24 may queue or run, with six per tenant.
- PostgreSQL commits durable receipts before acknowledgement. Database-clock leases and fencing reject stale workers. Captured responses can continue after recovery; uncertain model dispatches stay unknown. Replay executes nothing.
- Versioned v4 edits reference original source digests, captured excerpts and line ranges. The host validates bounds and mechanically renders patches. Accepted patches receive immediate registered checks before another model call.
- Complete context regions are selected within the actual rendered token budget. Issue, remaining budget and latest checks remain present. Omitted context and rejected edits remain inspectable.
- Disposable check containers use non-root identity, no runtime network, credentials or Docker socket, two CPUs and 1GB memory. Source edits are restricted to approved paths, three files and 200 changed lines. The original checkout stays untouched.
- Six calls, two applied patch versions, two check runs and ten minutes bound the loop. Independent drafts permit up to six fresh proposals and select the first two structurally valid candidates before checking either.

## Inspect the evidence

`/study` presents the complete frozen comparison: 36 attempts, zero verified repairs, with all 78 development/evaluation attempts retained. Eighteen new historical cases qualified: six each from Django, pytest and Requests. Six development cases selected the profile and adapter revision; twelve cases were locked before evaluation. Every attempted result, including infrastructure failures and interruptions, remains recorded. Development may not restart because evaluation disappoints.

`/capacity` preserves the original failed soak and the complete follow-up. The follow-up processed 435,270 requests across four three-minute stages and a 30-minute soak with zero errors or quota rejections; all declared local targets passed. Soak acknowledgement p95 was 275 ms and summary read p95 was 17 ms. Kairos inference, website and builds were stopped; a separate-project build finished before measurement; other shared-host activity was not exhaustively measured. The original database restart still has no proven root cause. Fixture traffic measures control-plane work, not inference, OIDC throughput or production scale. See [capacity evidence](docs/CAPACITY_004.md) and [final report](docs/FINAL_REPORT_004.md).

The original build003 study repaired one distinct case out of six under both baseline and loop. It established no loop advantage. The newer study and release acceptance status are in [build004](docs/BUILD_004.md), with a compact continuation map in [BRAIN.md](BRAIN.md). A failed model target does not erase software checks; passing software checks does not establish repair competence.

## Active module map

| Location | Responsibility |
| --- | --- |
| `kairos_api/investigations/` | Scoped routes, durable repository, registry, model adapter, bounded worker, edits and verification |
| `kairos_api/app.py`, identity modules | API composition, server sessions, tenant membership and role enforcement |
| `dashboard/lib/investigation-client.ts`, `hooks/useInvestigationWorkbench.ts` | Transport, command journal, stale-read protection and progress polling |
| `dashboard/components/Investigation*`, `app/investigations/` | Readable source, context, patch and check evidence; private and public inspection |
| `dashboard/app/study/`, `app/capacity/` | Frozen comparisons, measured costs and capacity failures |
| `cases/`, `scripts/qualify_study004.py`, `scripts/study004.py` | Frozen cases, exclusions, qualification, development limits and evaluation |
| `evidence/build004/`, `evidence/build003/` | Current receipts and preserved historical results |
| Existing jobs/effects/evaluation modules | Preserved single-dispatch jobs and labeled historical synthetic demonstrations |

Legacy harness/engine/ingest/storage modules are outside the active request path. Decisions and limits are in [ARCHITECTURE.md](ARCHITECTURE.md). The [five-minute demonstration](docs/INTERVIEW_DEFENSE.md) includes code questions and an unassessed personal ownership gate.

## Verification and limits

Run the isolated browser journeys with `npm --prefix dashboard run test:browser`. They use fixtures, not model repairs. Real OIDC/PostgreSQL browser journeys and opt-in model/Docker tests have separate commands and receipts. Frontend lint, types and build are independent checks. [Build004](docs/BUILD_004.md) names executed checks and remaining work; a configured CI job is not a hosted-CI result.

Local filesystem artifacts are fsynced before database references commit and are checked by content hash. This detects mismatches against stored references; it does not establish immutable history, signed provenance or offsite recovery. The trusted host worker controls Docker. Candidate Python shares the verifier environment with checks, so adversarial test-forgery resistance is unproven.

Historical public cases may occur in model training data. Human-localized source regions reduce the task’s difficulty. Results are descriptive, with no leaderboard, broad repair competence or loop-superiority claim. Public hosting, production scale, outside-user adoption, model research and the candidate’s personal mock defense remain separate milestones.
