# Kairos build007 working brain

Updated 2026-10-14. Active writable checkout: resume/kairos-build007, extracted from sealed build006 archive SHA256 a22d5b691c7b70d8c6256d415e9d98efa720741825cd77f3b81acdd5f36c7825. Original main installation and all historical source/data/images remain preserved.

## Fixed scope

Existing Mac, no hardware purchase/hosting. Heavy phases sequential. Docker only for required checks; turn it off afterward. Original model cache is read explicitly without copying weights. Guard6GiB study storage/4GiB free. User approved a separate free Gemini API development pilot and confirmed billing disabled. Key remains private in .runtime/free-model-pilot/environment.env; never print, copy or publish it.

## Implemented

Explicit ordered checksummed SQL migrations and catalog adoption; startup verifies only. Separate restricted reviewer runtime role with lock2s/statement15s deadlines. V2 missing-value backfill identities bind semantics; preserve old receipts. Portable study007 doctor/qualify/pilot/freeze/evaluate/report/stop. V7 captured source-line handles, exact feedback, duplicate candidate cache and repeated-invalid stop. Current website leads with readable source/patch/check evidence and /how-it-works; /advancement publishes every fresh result. Authoritative acceptance includes all backend tests and recorded, fault-fixture and actual-OIDC browsers.

## Measured outcomes

Five cases qualified(two Django/three pytest); six-case qualification target missed. Baseline0/5, loop0/5; combined0/10. Coder-r2 earned one already exposed development repair; two later format revisions performed worse. All36 development records(including12 zero-dispatch environment failures) and10 validation records captured.122 total public records/1243 blobs preserve original76/965. Historical0/36 and0/10 remain visible.

Free API v1 HTTP400 rejected unsupported MINIMAL thinking. Corrected v2 LOW request returned HTTP503 high-demand UNAVAILABLE. No proposal; uncertain dispatch retained with no retry. This is separate from locked local validation.

## Evidence and fixes

Focused post-review86 tests passed. Initial full reviewer acceptance357 passed/6 skips,8 recorded and4 real-OIDC browsers; final suite rerunning after reviewed additions. Actual pool/outage/held-lock drills passed,46 study rows preserved. Restored build006 adoption82 investigations/928 objects, historical rows unchanged. New non-root API/web images passed actual smoke. Docker isolation/output/missing-dependency probe passed. Original Django10914 repair reproduced110 tests/one skip under new007-reviewer image.

Review fixes: undefined legacy v4 variable; terminal reinspection overwrote timing; raw verifier output discarded prefixes; backfill checksum bound name only; runtime SQL waits lacked deadlines; reviewer omitted fixture phase and legacy test dependencies. Frozen source/locks/captures unchanged; delivery source delta records post-study fixes. Old evaluation refuses modified delivery source.

## Accepted delivery and handoff

Final full-stack acceptance:393 backend tests passed/six explicit opt-in skips;8 recorded,11 fault-fixture and4 real-OIDC journeys passed. Clean relocated checkout:277 passed/122 expected environment or opt-in skips,19 browser journeys, locked install/build; no initial runtime/credentials/DB/dependencies. Doctor validated the external model cache without starting Docker or inference. Frontend audit reports zero vulnerabilities. Heavy checks finished; owned containers and Docker Desktop stopped.

Read docs/FINAL_REPORT_007.md, USER_JOURNEYS_007.md, REVIEWER_007.md, CLAIMS_007.md and ARCHITECTURE_REVIEW_007.md. evidence/build007/final-checks.json is the software gate; quality_target remains false. Source archive/index/manifest/publication receipt have separate byte verification. Main installation is Desktop/new-karos; preserve .runtime, .git, historical raw files, volumes and images during promotion. Recorded reviewer demo uses3310 and no Docker. Promotion/seal receipts verify final handoff; no GitHub push/PR or paid human review.

Do not restart evaluation or resend the uncertain API call. Further model work requires a separately bounded experiment. Personal interview practice does not block software delivery and is not certified by tests.
