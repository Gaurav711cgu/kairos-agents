/// <reference types="next" />
/// <reference types="next/image-types/global" />
import "./.next-reviewer005/types/routes.d.ts";
import "./.next-reviewer005/types/root-params.d.ts";

// NOTE: This file should not be edited
// see https://nextjs.org/docs/app/api-reference/config/typescript for more information.
