import Link from "next/link";
import followup from "@/lib/followup006-cohort.json";

export const metadata = { title: "Your first investigation" };

const inspection = [
  { title: "Choose a recorded investigation", action: "Open a case that matches the behavior you want to inspect.", system: "Kairos loads the original issue, source revision and captured artifacts. It checks their hashes and references.", result: "You receive a trace you can inspect. No account, model or Docker is needed." },
  { title: "Understand the proposed change", action: "Read the issue, then open the source and patch views.", system: "Original source stays separate from the proposed candidate. Before and after views highlight changed lines.", result: "You can see what changed and where. A plausible patch still has to pass checks." },
  { title: "Read the observed checks", action: "Open the check step. Read the verdict, test count and failures.", system: "Registered checks run independently of model prose. Missing tests, environment errors and failed existing tests prevent a verified repair.", result: "You learn whether this candidate earned a repair outcome. Failed checks remain visible." },
  { title: "Compare and take the evidence", action: "Compare strategies, then download the patch and evidence bundle.", system: "Kairos shows additional calls, captured tokens and timing. Downloads preserve the captured bytes and their integrity checks.", result: "You receive a patch for human review and an inspectable record. Downloads do not change your repository." },
];

const execution = [
  { title: "Sign in and select a registered case", text: "A live local installation checks your workspace and role. Operators select a registered case and versioned configuration. Arbitrary repository URLs are not accepted." },
  { title: "Submit once; follow actual progress", text: "The browser saves a stable command identity. PostgreSQL commits the receipt before acknowledging it. A lost acknowledgement can be retried with the same identity. Queue limits produce explicit rejections." },
  { title: "Inspect, propose and check", text: "When the pinned inference server and worker are running, the worker claims one job. It captures source and context, proposes bounded edits and runs registered checks in disposable containers. The live control plane starts with inference off." },
  { title: "Receive the observed outcome", text: "A verified repair requires the regression and relevant existing tests to pass. You may instead receive failed checks, an invalid patch, an environment failure, a timeout or an unknown dispatch. Those outcomes include evidence; they do not become successful repairs." },
];

export default function HowItWorks() {
  return <div className="page-shell reading-page">
    <header className="page-heading"><span className="eyebrow">Start here</span><h1>From a defect<br /><em>to an inspectable result.</em></h1><p>What you do, what Kairos runs and what you receive. Begin with a saved investigation; use the private workbench for a new attempt.</p></header>
    <div className="article-layout">
      <aside className="article-index"><span className="eyebrow">Your path</span><a href="#inspect">Inspect a saved result</a><a href="#run">Run a new attempt</a><a href="#controls">Other actions</a><a href="#outcomes">Did it work?</a></aside>
      <article className="prose">
        <section id="inspect"><h2>Inspect a saved result.</h2><p>This is the first path for a reviewer. Open each step for the expected behavior.</p>
          {inspection.map((step, index) => <details className="journey-step" key={step.title}><summary><span aria-hidden="true">{index + 1}. </span>{step.title}</summary><div><p><strong>You:</strong> {step.action}</p><p><strong>Kairos:</strong> {step.system}</p><p><strong>Result:</strong> {step.result}</p></div></details>)}
          <div className="investigation-actions"><Link className="text-link" href={`/investigations/${followup.featured_id}`}>Inspect the recorded repair</Link><Link className="text-link" href="/investigations">Browse all investigations</Link></div>
        </section>
        <section id="run"><h2>Run a new attempt.</h2><p>A new investigation requires the authenticated stack, a qualified source case, the pinned local model and a worker. Recorded mode offers inspection only.</p>
          <ol>{execution.map(step => <li key={step.title}><h3>{step.title}</h3><p>{step.text}</p></li>)}</ol>
          <Link className="text-link" href="/workbench">Open the workbench</Link>
        </section>
        <section id="controls"><h2>Other actions have specific boundaries.</h2>
          <p><strong>Cancel:</strong> stop queued work or fence later commits. Already-started inference cannot be undone.</p>
          <p><strong>Fork:</strong> start a fresh attempt linked to its parent. It has its own receipt and budgets.</p>
          <p><strong>Replay:</strong> inspect saved steps. Replay sends no model calls and executes no tools.</p>
          <p><strong>Publish:</strong> an administrator makes a private record publicly inspectable. Other roles cannot publish.</p>
          <p><strong>Retry:</strong> reuse the same command identity after an uncertain submission. An unknown model dispatch is preserved without being sent again.</p>
        </section>
        <section id="outcomes"><h2>Did the person get the result?</h2><p>Inspection succeeds when the person can see the source, candidate, checks and original downloads. A new repair succeeds only when its captured candidate passes the registered verification. These are separate results.</p><p>The recorded Django repair passed its declared checks. Fresh v7 validation remains 0/10 across five qualified Django and pytest cases. The earlier v5 validation remains 0/10, and the older study remains 0/36. Both unsuccessful comparisons remain available beside the earned demonstrations.</p><p>Browser journeys exercise the user actions, roles, errors, downloads, keyboard controls and mobile layout. Their receipts state actual outcomes. Passing those journeys proves the tested interaction; it does not guarantee that every model attempt repairs a defect.</p><div className="investigation-actions"><Link className="text-link" href="/follow-up">Read every follow-up outcome</Link><Link className="text-link" href="/docs">Run the checks yourself</Link></div></section>
      </article>
    </div>
  </div>;
}
