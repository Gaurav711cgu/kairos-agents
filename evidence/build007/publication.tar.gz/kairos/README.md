# Kairos

A full-stack workbench for investigating repository defects, inspecting proposed patches and checking the evidence.

Start at `/how-it-works`, inspect a genuine Django development repair, then compare it with every failed fresh attempt. Build007 adds explicit SQL migrations, portable study tooling, source-line edits, bounded operational drills and a readable user journey. The recorded package contains 122 investigations and 1,243 original artifact blobs.

Current handoff: [build007 report](docs/FINAL_REPORT_007.md), [reviewer guide](docs/REVIEWER_007.md), [user behavior results](docs/USER_JOURNEYS_007.md) and [claim map](docs/CLAIMS_007.md). Fresh local-model validation remains **0/10** across five qualified Django/pytest cases. One development repair is separate. Historical 0/36 and 0/10 remain visible. The optional free API development probe returned no proposal and does not replace the frozen local study.

## Run the reviewer website

Requires Python 3.12 or newer and Node.js 24 on macOS or Linux. From the repository root:

```bash
python3 -m scripts.reviewer demo
```

The command installs locked website dependencies, builds the website and serves it at `http://127.0.0.1:3310`. It uses genuine published captures, verifies their artifact bytes and performs no live inference. No Docker, database, API key or account is needed. The website labels recorded evidence and closes private execution. Live API errors never silently become demonstration data.

Ctrl-C stops the command's owned website process. To stop a previously launched reviewer environment:

```bash
python3 -m scripts.reviewer stop
```

## Run the isolated full stack

Requires Docker in addition to the dependencies above:

```bash
python3 -m scripts.reviewer fullstack
```

This creates a separate PostgreSQL/Keycloak environment with generated private credentials and launches the actual API and website. Ports: PostgreSQL 55434, Keycloak 8090, API 8310 and website 3310. It preserves the prepared installation, existing volumes and historical images. Credential files stay under ignored `.runtime/reviewer005`; do not commit them.

Inference is off by default. Queue, cancellation, stable retries, authorization, fork and recorded replay exercise the real control plane. Model execution requires a separately prepared pinned runtime and source/verification environments. Recorded imports remain historical evidence, not newly executed repairs.

## Reproduce the earned repair

With Docker available:

```bash
python3 -m scripts.reviewer repair
```

The command prepares the pinned Django source in a separate directory, builds a reviewed verification image under a new tag and applies the recorded model patch in a disposable copy. It requires no model or database. A rebuilt image is an explicit environment change, not the byte-identical original evaluation. Actual checks and image provenance are written to the reviewer runtime.

## Run acceptance checks

```bash
python3 -m scripts.reviewer check
python3 -m scripts.reviewer check --fullstack
```

The first command covers recorded evidence, frontend tests and reviewer browser inspection. Full-stack checks additionally use actual PostgreSQL, Keycloak and authenticated browser journeys. The command reports failures and skipped opt-in checks; test fixtures are never counted as model repairs. Stop the current reviewer mode before running checks. The full-stack check provisions its own isolated services and stops its owned processes afterward.

[Current reviewer instructions](docs/REVIEWER_007.md) describe the new evidence and the unchanged entry point. [Build005 reviewer instructions](docs/REVIEWER_005.md) retain historical setup details. [The five-minute demo](docs/DEMO_007.md) walks through the current investigation, complete comparisons and engineering evidence. The separate original Django file-permissions reproduction runs 110 tests with one upstream skip. [Claims and résumé bullets](docs/CLAIMS_007.md) link each current or historical statement to its receipt. [The architecture assessment](docs/ARCHITECTURE_REVIEW_007.md) gives separate verdicts for software reliability and AI effectiveness.

[Build005 acceptance](docs/FINAL_REPORT_005.md) records its completed checks. [DECISIONS.md](DECISIONS.md) explains the choices and their evidence. The following command verifies the preserved build005 delivery inventory and lossless historical archives when run from its unchanged build005 source snapshot. It does not certify modified build006 source:

```bash
python3 -m scripts.verify_delivery005
```

## What the evidence supports

- Durable PostgreSQL command receipts, workspace-scoped retries and conflicts, database-clock leases and fencing. Captured results can continue after recovery; uncertain dispatches remain unknown. Replay executes nothing.
- OIDC authorization, tenant boundaries, authenticated integrity downloads, keyset pagination and bounded queues. One investigation executes globally within an installation; queue/running ceiling 24, active tenant ceiling six.
- Original-source-bound edits, selected context, explicit omissions and registered Docker checks. Limits: six model calls, two applied patches, two check runs and ten minutes.
- A local control-plane follow-up processed 435,270 requests over 42 minutes with zero unexpected errors or quota rejections. The ten-client soak measured acknowledgement p95 275.19 ms and read p95 16.79 ms. The original failed soak remains preserved. This is not inference throughput or production scale.
- Two SIGKILL recovery drills made zero additional model dispatches. A fresh consistent restore verified 109 investigations, 1,145 distinct objects and 1,546 references.

[Build004's final report](docs/FINAL_REPORT_004.md) contains the executed engineering checks and frozen study. [Capacity evidence](docs/CAPACITY_004.md) preserves every run. Build005 is a delivery release; it does not retune or replace those results.

## Explicit schema setup

API and worker startup verify the schema without DDL or backfills. A separate private owner credential performs ordered migrations before runtime starts:

```bash
python3 -m scripts.migrate status
python3 -m scripts.migrate apply
python3 -m scripts.migrate apply --backfill
```

Use `KAIROS_MIGRATION_DATABASE_URL` only in private setup state. The reviewer provisions a separate restricted runtime role. See [migration decisions](DECISIONS.md) and [build007 architecture review](docs/ARCHITECTURE_REVIEW_007.md). Do not run historical study compatibility commands against locked evaluation receipts.

## Active module map

| Location | Responsibility |
| --- | --- |
| `kairos_api/investigations/` | Scoped commands, durable repository, fenced worker, context/actions, source edits and verification |
| `kairos_api/migrations.py`, `migrations/`, `backfill_operations.py` | Explicit versioned schema adoption, checksummed revisions and missing-value operations |
| `kairos_api/identity.py`, `app.py` | OIDC/server sessions, membership, roles and API composition |
| `dashboard/lib/`, `hooks/`, `components/Investigation*` | Evidence readers, transport, stable command journal and readable inspection |
| `scripts/reviewer*.py` | Clean-entry setup, isolated services, repair reproduction, acceptance and scoped shutdown |
| `dashboard/evidence/` | Genuine published captures and original digest-addressed artifact bytes |
| `cases/`, study scripts | Historical provenance, qualification, frozen evaluation and complete attempt ledgers |
| `evidence/`, `docs/` | Receipts, compressed raw measurements, preserved sources and engineering explanations |

Legacy harness, engine and ingestion modules are outside the active investigation request path. Earlier synthetic demonstrations remain labeled separately.

## Limits and preservation

Build003 earned two verified attempts on one distinct Django case; single call and loop repaired the same case. Build004 qualified 18 cases, developed on six and evaluated 12 with three frozen strategies: 0/36 verified evaluation repairs. All 78 build004 development/evaluation attempts remain recorded. Build006 adds 28 attempts separately. Its five fresh qualified cases produced 0/10 verified repairs across baseline-v5 and loop-v5. V6 is a separate development reasoning experiment: 2/6 verified attempts on the same Django11066 case, one invalid response, two failed checks and one unknown dispatch. Public cases may occur in training, source entry files were human-localized, and the successful development issue supplies the proposed fix. No broad repair or loop-superiority claim is supported.

Captured hashes establish consistency with stored references, not immutable administrative history. The trusted host worker controls Docker. Candidate Python shares the verifier environment, so adversarial test-forgery resistance is unproven. Local restore does not establish offsite disaster recovery.

Build003/build004 source and receipts and the exact build005 publication archive remain preserved. Oversized raw measurements have a lossless compressed publication copy and per-file hash index; original local files are unchanged. Runtime state, credentials, sessions and model weights are excluded from publication. Lenovo inference, public hosting, external adoption and personal interview performance remain separate milestones. Build006 local acceptance passed; its separate manifest and publication receipt bind the tested source and evidence. Verify with `python3 -m scripts.package_release006 --verify`. The prepared snapshot has not been pushed or publicly hosted.

[Overload and failure workflows](docs/OVERLOAD_WORKFLOWS_006.md) map saturation, timeout, recovery and cancellation to the actual bounded controls and their measured limits.
