"""Bounded loop. Dispatch intent commits before local inference; recovery never guesses."""
import json
import time
from uuid import uuid4
from pydantic import ValidationError
from kairos_api.investigations.contracts import Action
from kairos_api.investigations.model import LocalInvestigator
from kairos_api.investigations.repository import InvestigationRepository
from kairos_api.investigations.sandbox import Workspace
from kairos_api.model_runtime import digest, strict_json

ENTRY_LINES={'kairos_api/jobs_repository.py':245,'django/db/models/sql/compiler.py':320,
             'django/db/models/sql/query.py':1750,'django/conf/global_settings.py':275}


class InvestigationWorker:
    def __init__(self,repository=None,provider=None,workspace=Workspace):
        self.repository=repository or InvestigationRepository()
        self.provider=provider or LocalInvestigator()
        self.workspace_factory=workspace
        self.owner='investigator-'+uuid4().hex

    def run_once(self):
        job=self.repository.claim(self.owner)
        if not job: return None
        workspace=None
        try:
            case=self.repository.registry.get(job['task_id'])
            if self.repository.registry.fingerprint(case)!=job['task_digest']:
                raise ValueError('Registered case changed after enqueue')
            if job['config_snapshot']['model_manifest_digest']!=self.repository._model_digest():
                raise ValueError('Pinned model manifest changed after enqueue')
            workspace=self.workspace_factory(self.repository.registry,case)
            return self._run(job,workspace)
        except TimeoutError:
            return self.repository.finish(job,'timeout','Investigation deadline exhausted')
        except RuntimeError:
            # Cancellation and stale fencing cannot authorize a final write.
            return self.repository.read(str(job['id']),job['tenant_id'])
        except Exception as error:
            return self.repository.finish(job,'environment_failure',type(error).__name__+': '+str(error)[:500])
        finally:
            if workspace: workspace.close()

    def _record(self,job,kind,name,request,result):
        seq=self.repository.begin(job,kind,name,request)
        self.repository.capture(job,seq,result)
        return seq

    def _state(self,job,workspace):
        record=self.repository.read(str(job['id']),job['tenant_id'])
        if not record['integrity']['verified']: raise ValueError('Captured step integrity mismatch')
        observations=[];patch='';verification=None;invalid=False
        for step in record['steps']:
            if step['kind']!='tool' or step['state']!='captured': continue
            request=step['request']['body'];result=step['result']['body']
            if step['name']=='propose_patch':
                invalid='error' in result
                if not invalid: patch=result.get('patch',request.get('patch',''));verification=None
            if step['name']=='run_checks' and result.get('patch_digest')==digest(patch): verification=result
            observations.append({'action':step['name'],'result':result})
        if patch: workspace.propose(patch)
        if not observations:
            for path in workspace.case['entry_files']:
                observations.append({'action':'initial_source','result':workspace.read(path,ENTRY_LINES.get(path,1))})
        return record,observations,patch,verification,invalid

    def _verify(self,job,workspace,patch,model_seq=None):
        seq=self.repository.begin(job,'tool','run_checks',{'action':'run_checks','model_seq':model_seq,'patch_digest':digest(patch)})
        result=workspace.checks(float(self.repository.remaining(job)))
        result['patch_digest']=digest(patch)
        self.repository.capture(job,seq,result)
        return result

    def _outcome(self,job,workspace,patch,verification,invalid,summary):
        if patch and verification is None:
            record=self.repository.read(str(job['id']),job['tenant_id'])
            if record['check_count']<job['config_snapshot']['budgets']['max_checks']:
                verification=self._verify(job,workspace,patch)
        if verification and verification.get('environment_error'): outcome='environment_failure'
        elif patch and verification and verification.get('passed'): outcome='verified_repair'
        elif patch: outcome='failed_checks'
        elif invalid: outcome='invalid_patch'
        else: outcome='no_patch'
        return self.repository.finish(job,outcome,summary)

    def _run(self,job,workspace):
        while True:
            if self.repository.remaining(job)<=0: raise TimeoutError()
            record,observations,patch,verification,invalid=self._state(job,workspace)
            handled={s['request']['body'].get('model_seq') for s in record['steps'] if s['kind']=='tool' and s['state']=='captured'}
            models=[s for s in record['steps'] if s['kind']=='model' and s['state']=='captured' and s['seq'] not in handled]
            if models:
                model=models[-1]
                response=model['result']['body']
            else:
                if record['model_calls']>=job['config_snapshot']['budgets']['max_calls']:
                    return self._outcome(job,workspace,patch,verification,invalid,'Model call budget reached')
                request,context=self.provider.prepare(workspace.case,job['configuration'],observations,
                    {'calls_remaining':job['config_snapshot']['budgets']['max_calls']-record['model_calls'],
                     'patches_remaining':job['config_snapshot']['budgets']['max_patches']-record['patch_count'],
                     'checks_remaining':job['config_snapshot']['budgets']['max_checks']-record['check_count']})
                self._record(job,'context','selection',{'configuration':job['configuration']},context)
                seq=self.repository.begin(job,'model','dispatch',request)
                try: response=self.provider(request,float(self.repository.remaining(job)))
                except Exception as error:
                    # Transport uncertainty is not evidence that the provider did no work.
                    return self.repository.finish(job,'unknown_dispatch',type(error).__name__+': '+str(error)[:300])
                self.repository.capture(job,seq,response)
                model={'seq':seq}
            try:
                choice=response['choices'][0]
                if choice['finish_reason']!='stop': raise ValueError('Model response truncated or interrupted')
                parsed=strict_json(choice['message']['content'])
                action=Action.validate_python(parsed).model_dump()
            except (ValueError,ValidationError,KeyError,IndexError,TypeError) as error:
                return self.repository.finish(job,'invalid_response',str(error)[:500])
            name=action['action']
            if job['configuration'].startswith('baseline-') and name not in {'propose_patch','final_result'}:
                return self.repository.finish(job,'invalid_response','Single-call baseline requires a patch or final result')
            if name=='final_result':
                return self._outcome(job,workspace,patch,verification,invalid,action['summary'])
            request={**action,'model_seq':model['seq']}
            try:
                if name=='run_checks':
                    self._verify(job,workspace,patch,model['seq']);continue
                seq=self.repository.begin(job,'tool',name,request)
            except ValueError:
                return self._outcome(job,workspace,patch,verification,invalid,'Tool budget exhausted')
            try:
                if name=='search': result=workspace.search(action['query'])
                elif name=='read_file': result=workspace.read(action['path'],action['start_line'])
                else: result=workspace.propose_edits(action['edits'])
            except (ValueError,OSError) as error: result={'error':str(error)[:1000]}
            self.repository.capture(job,seq,result)


def main():
    repository=InvestigationRepository();repository.initialize()
    worker=InvestigationWorker(repository)
    while True:
        result=worker.run_once()
        if result: print(json.dumps({'id':result['id'],'task_id':result['task_id'],'outcome':result['outcome']}),flush=True)
        else: time.sleep(1)

if __name__=='__main__': main()
