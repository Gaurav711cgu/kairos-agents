"""Pinned local inference adapter with measured context selection."""
import json
import os
from urllib.parse import urlparse
import httpx
from kairos_api.investigations.contracts import Action, GENERATION, SYSTEM


class LocalInvestigator:
    def __init__(self):
        self.endpoint=os.environ.get('KAIROS_INVESTIGATION_MODEL_URL','http://127.0.0.1:8130')
        parsed=urlparse(self.endpoint)
        if parsed.scheme!='http' or parsed.hostname not in {'127.0.0.1','localhost','::1'} or parsed.username or parsed.query or parsed.fragment:
            raise ValueError('Investigations require a configured loopback model endpoint')

    def prepare(self,case,configuration,observations,budgets):
        value={'issue':case['issue'][:4500],'source_revision':case['revision'],'approved_source':case['approved_prefix'],
               'budgets':budgets,'observations':observations[-4:],
               'latest_verification': next((str(o['result'])[-2000:] for o in reversed(observations) if o['action']=='run_checks'),None)}
        system=SYSTEM
        if configuration.startswith('baseline-'): system+=' This is a single-call baseline. Choose propose_patch or final_result now.'
        omitted=list(range(max(0,len(observations)-4)))
        with httpx.Client(timeout=10,trust_env=False) as client:
            while True:
                text=json.dumps(value,ensure_ascii=False)
                response=client.post(self.endpoint+'/tokenize',json={'content':system+'\n'+text,'add_special':True})
                response.raise_for_status();count=len(response.json()['tokens'])
                if count<=2750: break
                if value['observations']:
                    # Drop oldest evidence first, preserving issue/budgets. Record the choice.
                    omitted.append(max(0,len(observations)-len(value['observations'])))
                    if len(value['observations'])==1:
                        encoded=json.dumps(value['observations'][0],ensure_ascii=False)
                        value['observations'][0]={'excerpt':encoded[:max(300,len(encoded)//2)],'truncated':True}
                        if len(encoded)<=350: raise ValueError('Context cannot fit pinned token budget')
                    else: value['observations'].pop(0)
                elif len(value['issue'])>600: value['issue']=value['issue'][:len(value['issue'])//2]
                else: raise ValueError('Context cannot fit pinned token budget')
        request={'messages':[{'role':'system','content':system},{'role':'user','content':json.dumps(value,ensure_ascii=False)}],
                 **GENERATION,'response_format':{'type':'json_schema','json_schema':{'name':'investigation_action','strict':True,'schema':Action.json_schema()}}}
        return request,{'input_tokens_before_chat_template':count,'reserved_template_tokens':322,'output_tokens':1024,
                        'omitted_observation_indices':sorted(set(omitted)), 'issue_truncated':value['issue']!=case['issue'],
                        'selection':value}

    def __call__(self,request,seconds=120):
        with httpx.Client(timeout=httpx.Timeout(min(120,float(seconds)),connect=5),trust_env=False) as client:
            with client.stream('POST',self.endpoint+'/v1/chat/completions',json=request) as response:
                response.raise_for_status()
                body=bytearray()
                for chunk in response.iter_bytes():
                    if len(body)+len(chunk)>1000000: raise ValueError('Model response exceeds capture limit')
                    body.extend(chunk)
                return json.loads(body)
