# Kairos working brain

Updated 2026-10-11. **Build003 investigation workflow implemented; local acceptance completed; receipts sealed under evidence/build003.** Model results are separate: both approaches repaired the same one of six real cases. No loop advantage demonstrated. Public hosting/adoption/research remain separate.

## Location and scope

Repo `/Users/gauravkumarnayak/Desktop/new-karos`; `resume/new-karos` is a symlink. Preserve unrelated uncommitted work, earlier docs/evidence and existing jobs. Actual repo requires escalated host writes under this workspace policy. Never expose ignored credential files. No commit/push/deploy requested.

## Read only what matters

Start `docs/BUILD_003.md`, `evidence/build003/attempts.json`, `evaluation-lock-v3.json`, `case-preflight.json`, then relevant source. README has startup and repair reproduction commands. Architecture D29 onward describes investigations. Build002 and design003 receipts are historical, preserved. Do not rescan the whole repo.

## Active implementation

`kairos_api/investigations/`: strict four-tool actions/final result, source registry, bounded exact replacements, Docker sandbox, PostgreSQL repository, local schema-constrained Qwen3 adapter, durable worker and scoped APIs. Additive investigation/step/artifact tables preserve old jobs.

Limits: six calls, two proposals, two check runs, ten minutes; one active investigation globally. Model context4096/output1024/thinking off. Database-clock leases/fencing, durable dispatch intent and fsynced CAS; unknown dispatch never silently retries. Captured response can continue; replay executes nothing. Private default/admin publish. Patches source-only/3 files/200 lines. Disposable UID10001 container, no network/credentials/socket,2 CPU/1GB.

Native runtime official Qwen3-1.7B-GGUF Q8_0 and llama.cpp b11552, hashes in inference-runtime/runtime-verification. Setup supports macOS ARM64. Runtime about2.1GB, runtime-tree cap6GiB/free reserve4GiB; shared Docker cache has no project quota. Never run heavy builds beside inference on8GB host: swap previously tripped reserve, preserved failure receipt.

Website: real investigation homepage, ledger, detail with readable before/after source, check summaries, collapsed raw evidence, comparison/context/timeline/downloads, registered-case private workbench. Muted colors, sentence-case editorial labels, original raw issue unchanged. Frozen cohort IDs separate later interactive records. Synthetic old homepage under `/history`; old URLs preserved.

## Evidence and known limits

Six qualified cases: development clock/Django10554/10880; validation body/Django10914/10973. All original failures/reference fixes reproduce. Django10097 excluded before inference; reference suite failed. Human-selected entry files/lines, public training contamination possible. Clock regression is controlled connection/timestamp fixture; not livePG in case container. Hidden checks/reference outside tools; candidate Python shares its test process/container, so no hostile-code secrecy claim.

Finalv3:12attempts,2verified on1distinctcase; baseline6calls/13357tokens,loop25calls/33117tokens (check ledger if editing metrics). Django10914 is one-line permission default;110tests/1skip, fresh reproduction passed. Earlier v1/v2 12failures retained. Schema format initially accepted but ignored; v3 enforced nested format proven live. Post-eval corrupt-download guard and sandbox --pull=never added; evaluated routes/sandbox archived and verified against lock. Other frozen modules unchanged. Do not retune/rerun validation and present it as untouched.

Tests: final199passed/0skipped/2dependencywarnings; frontend4boundary tests plus lint/types/build and final images pass. Real SIGKILL intent/captured drills each0redispatch. Restore receipt25investigations at its snapshot. Browser private queue/cancel/fork records local-studio remain private, outside cohort. Final receipts/screen captures underbuild003; manifests are local fingerprints, not immutable history.

Ports: web3100/API8100/model8130/PG55432/Keycloak8088. `run_local.py investigator` separate trusted hostworker. Stop model before builds; restart native server afterward. Existing single-call Qwen2.5 service8120 remains historical. API/web Dockerbuild003 active; don't overwrite historicalbuild002 image used by frozen cases. No provider fallback/API spend. Legacy harness/engine/ingest/storage inactive.
