import Link from "next/link";

export const metadata = { title: "Engineering decisions" };

export default function Engineering() {
  return (
    <div className="page-shell reading-page">
      <div className="page-heading">
        <span className="eyebrow">Engineering / Failure boundaries</span>
        <h1>
          How Kairos works.
          <br />
          <em>Decisions and tradeoffs.</em>
        </h1>
        <p>
          The request path, worker recovery, context capture and release checks.
          Each section explains the implementation and its limits.
        </p>
      </div>
      <div className="article-layout">
        <aside className="article-index">
          <span className="eyebrow">System blueprint</span>
          <a href="#investigations">Repository investigations</a>
          <a href="#durability">01 Commit before response</a>
          <a href="#workers">02 Fenced durable workers</a>
          <a href="#context">03 Context is evidence</a>
          <a href="#grading">04 Independent grading</a>
          <a href="#identity">05 Identity and effects</a>
          <a href="#integrity">06 Integrity and limits</a>
        </aside>
        <article className="prose">
          <section id="investigations">
            <span className="eyebrow">Build 003 / Active workflow</span>
            <h2>A bounded investigation, with an independent verdict.</h2>
            <p>A registered case pins a source revision, Docker image and verification recipe. Four tools expose literal search, source excerpts, exact source replacements and registered checks. The model has six calls, two patch proposals, two check runs and ten minutes. A single-call baseline uses the same model and verifier.</p>
            <p>PostgreSQL records dispatch intent, fencing tokens and ordered captures. Content-addressed files are fsynced before references commit. An uncertain model call stays unknown; a captured response can continue after recovery. Replay reads saved evidence without executing.</p>
            <p>Candidate code runs as a non-root user in a disposable container: no network, credentials or Docker socket, two CPUs and 1 GB memory. Source tools cannot read reference fixes or hidden checks. Verification uses a separate copy. This is local isolation, not a claim that tests are secret from hostile Python running inside the verifier.</p>
            <p>One of six cases was repaired by both approaches. The loop used more inference without improving coverage. Earlier development failures and a corrected schema-adapter error remain in the ledger. Historical synthetic release gates below have a separate scope.</p>
            <Link className="text-link" href="/investigations">Inspect the complete comparison</Link>
          </section>
          <section id="durability">
            <span className="eyebrow">01 / Storage correctness</span>
            <h2>Commit before acknowledgement.</h2>
            <p>
              A memory-buffer acknowledgement cannot establish durable capture.
              FastAPI commits a tenant-scoped request receipt and its result in
              PostgreSQL before returning success. Reference runs fit one short
              transaction; slow model work does not.
            </p>
            <div className="engineering-flow">
              <span>Authorize</span>
              <b>→</b>
              <span>Validate request</span>
              <b>→</b>
              <strong>Commit receipt</strong>
              <b>→</b>
              <span>Respond</span>
            </div>
            <h3>Why this tradeoff</h3>
            <p>
              PostgreSQL owns the initial durable boundary. Synchronous commit
              is required, and startup rejects disabled fsync. Duplicate request
              keys return the recorded result; conflicting payloads fail. The Go
              prototype is excluded from this product path.
            </p>
          </section>
          <section id="workers">
            <span className="eyebrow">02 / Loop control</span>
            <h2>Worker leases and crash recovery</h2>
            <p>
              A worker claims a durable job with a lease and fencing token,
              captures dispatch intent, calls the model outside the database
              transaction, then stores the response and grades it. Attempts,
              deadlines, cancellation and model-call budgets bound the loop.
            </p>
            <p>
              A stale worker cannot overwrite a newer lease. If dispatch
              happened without a captured response, the job becomes unknown.
              Recovery can continue from a known captured result; it never
              silently sends an unknown model call again. Fresh forks have
              separate lineage.
            </p>
            <Link className="text-link" href="/executions">
              Inspect durable execution records
            </Link>
          </section>
          <section id="context">
            <span className="eyebrow">03 / Harness observability</span>
            <h2>Preserve what the runner received.</h2>
            <p>
              The late-order exception scenario has two policies. Compact drops
              the exception block; preserve retains it. Records include the full
              source, inclusion decisions, proposed output and ordered events.
              The homepage context control uses that recorded evidence.
            </p>
            <p>
              The reference runner isolates the context dependency. Model jobs
              preserve rendered requests and unmodified responses. The model
              selects refund, zero or abstain; a deterministic tool calculates
              cents. Invalid schema, unsupported citations and wrong policy
              choices remain failures.
            </p>
            <Link className="text-link" href="/incidents">
              Open the context experiment
            </Link>
          </section>
          <section id="grading">
            <span className="eyebrow">04 / Evaluation boundary</span>
            <h2>Independent grading</h2>
            <p>
              The grader reads complete source facts independently of the
              runner’s selected context. Removing an exception changes
              execution, not scoring truth. A transport success is not a task
              success.
            </p>
            <p>
              The fixed-sample release rule uses a paired Hoeffding bound with
              alpha 0.05, noninferiority margin 0.10 and 1,024 predeclared
              synthetic holdout tasks. PASS requires the lower bound to exceed
              −0.10. FAIL follows a hard invariant failure or an upper bound
              below −0.10. Other outcomes are INCONCLUSIVE.
            </p>
            <p>
              Deterministic null calibration and planted regressions check gate
              behavior. They do not qualify a model. The 32-task development
              model report retains 12 responses and 20 provider errors; its
              three passing tasks do not constitute 32 valid model observations
              or holdout qualification.
            </p>
            <Link className="text-link" href="/reports">
              Inspect bounds, checks and task rows
            </Link>
          </section>
          <section id="identity">
            <span className="eyebrow">05 / Authorization and side effects</span>
            <h2>Authentication and approvals</h2>
            <p>
              Local Keycloak OIDC uses authorization code flow, PKCE, state and
              nonce. Opaque HttpOnly sessions stay on the server. PostgreSQL
              membership determines tenant and role; each request rechecks
              active membership. Browser writes require the configured Origin.
            </p>
            <p>
              A sandbox adjustment requires explicit approval bound to tenant,
              source run, proposal digest and version. A stable effect identity
              and receipt reconcile a response lost after commit. This is a
              PostgreSQL sandbox contract; no commercial payment is sent.
            </p>
            <Link className="text-link" href="/workbench">
              Open authenticated workbench
            </Link>
          </section>
          <section id="integrity">
            <span className="eyebrow">06 / Integrity without overclaim</span>
            <h2>Content hashes and their limits</h2>
            <p>
              Run documents and ordered events carry SHA-256 consistency checks.
              Model payloads also use fsynced, content-addressed filesystem
              blobs. Reads verify the referenced content and scope access to its
              owning job.
            </p>
            <aside className="scope-note">
              <strong>What this does not establish</strong>
              <p>
                Hashes do not make privileged history immutable. The local
                filesystem is not an S3 deployment. Synthetic evaluations do not
                establish real-world safety. Local drills do not establish
                customer adoption or hosted production operations.
              </p>
            </aside>
            <Link className="text-link" href="/evidence">
              Review available evidence
            </Link>
          </section>
        </article>
      </div>
    </div>
  );
}
