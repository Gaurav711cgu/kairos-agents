import Link from "next/link";
import { isFrozenComparison, getInvestigation, getInvestigations, outcomeLabel, caseTitle, configurationLabel } from "@/lib/investigations";
import { InvestigationRows } from "@/components/InvestigationRows";
import { ServiceError } from "@/components/IncidentRows";
export const dynamic = "force-dynamic";
export default async function Home() {
  const result = await getInvestigations();
  const records = result.data?.investigations ?? [];
  const latest = records.filter(isFrozenComparison);
  const featured = latest.find(item=>item.outcome==="verified_repair") ?? latest.find(item=>item.configuration.startsWith("loop-")) ?? records[0];
  const detail = featured ? await getInvestigation(featured.id) : null;
  const record = detail?.data;
  const patch = [...(record?.steps ?? [])].reverse().find(item=>item.name==="propose_patch" && item.result && !item.result.body.error);
  const patchText = patch?.result?.body.patch ?? patch?.request.body.patch;
  const rejection = [...(record?.steps ?? [])].reverse().find(item=>item.name==="propose_patch" && item.result?.body.error)?.result?.body.error;
  const cases = new Set(latest.map(item=>item.task_id)).size;
  const repaired = latest.filter(item=>item.outcome==="verified_repair").length;
  return <>
    <div className="site-meta"><span>Real repository investigations</span><span>{result.error ? "Records unavailable" : `${records.length} recorded attempts`}</span></div>
    <section className="hero investigation-hero">
      <div className="hero-copy"><span className="eyebrow opening-label">Kairos / Repository investigation</span>
        <h1>Read the attempt.<br /><em>Judge the result.</em></h1>
        <p className="hero-deck">An agent proposes a source change.<br />Independent checks decide whether it works.</p>
        <p className="hero-description">Historical bugs in Kairos and Django. Follow the evidence selected, inspect the actual model response, and compare a single call with a bounded tool loop.</p>
        <div className="hero-actions"><Link className="button primary" href={featured ? "/investigations/"+featured.id : "/investigations"}>Inspect an investigation</Link><Link className="button dark" href="/investigations">All attempts</Link><Link className="text-link" href="/engineering">Engineering decisions</Link></div>
        <dl className="home-investigation-metrics"><div><dt>Real cases evaluated</dt><dd>{result.error ? "—" : cases}</dd></div><div><dt>Verified repairs</dt><dd>{result.error ? "—" : repaired}<small>{result.error ? " unavailable" : " / " + latest.length + " attempts"}</small></dd></div><div><dt>API spend</dt><dd>$0<small> local inference</small></dd></div></dl>
        <p className="hero-footnote">Six human-localized cases. Historical controlled reproductions. Small sample; no general performance claim.</p>
      </div>
      <div className="hero-instrument case-dossier">{record ? <>
        <div className="dossier-top"><span className="eyebrow">Published case file</span><span>{configurationLabel(record.configuration)}</span></div>
        <h2>{caseTitle(record.task_id, record.task_snapshot.title)}</h2><p className="dossier-source">{record.task_snapshot.repository} · {record.task_snapshot.revision.slice(0,12)}</p>
        <div className="dossier-result"><span className="eyebrow">Observed result</span><h3 className={record.outcome==="verified_repair" ? "result-pass" : ""}>{outcomeLabel(record.outcome,record.status)}</h3><p>{record.model_calls} model {record.model_calls === 1 ? "call" : "calls"} · {record.patch_count} patch {record.patch_count === 1 ? "proposal" : "proposals"} · {record.check_count} check {record.check_count === 1 ? "run" : "runs"}</p></div>
        {typeof patchText==="string" ? <pre role="region" className="dossier-patch" tabIndex={0} aria-label="Proposed patch excerpt">{patchText.split("\n").filter(line => /^[+@-]/.test(line)).slice(0,10).join("\n")}</pre> : <div className="dossier-note"><span className="eyebrow">What the record contains</span><p>{typeof rejection==="string" ? rejection : record.summary || "Captured requests and responses, with the stop reason preserved."}</p></div>}
        <Link className="dossier-open" href={"/investigations/"+record.id}>Open source, context and checks<span aria-hidden="true">↗</span></Link>
      </> : <ServiceError message={detail?.error ?? result.error ?? "No real investigation has been published yet."} />}</div>
    </section>
    <section className="section"><div className="section-heading"><div><span className="eyebrow">How to review a result</span><h2>Start with the failure.<br /><em>Follow the evidence.</em></h2></div><p>A repair must fix the reproduced regression and pass the relevant existing tests.</p></div>
      <div className="architecture-notes"><article><span className="note-number">01</span><h3>Inspect the source</h3><p>Each case identifies the issue, pinned revision and reproduction command. A baseline failure and passing reference repair establish the case before the agent runs.</p></article><article><span className="note-number">02</span><h3>Read the proposed change</h3><p>The model supplies exact source replacements. Kairos constructs the diff and rejects changes outside approved source paths. Every rejected proposal remains inspectable.</p></article><article><span className="note-number">03</span><h3>Check the result</h3><p>Checks run in a separate disposable environment without network access. A model saying it succeeded cannot approve its own repair.</p></article></div>
    </section>
    <section className="section"><div className="section-heading"><div><span className="eyebrow">Recorded comparison</span><h2>What actually happened.</h2></div><p>Open a tool-loop attempt to compare its single-call baseline. Earlier development attempts remain in the full record.</p></div>{result.error ? <ServiceError message={result.error}/> : <InvestigationRows records={latest.filter(item=>item.configuration.startsWith("loop-"))} />}<div className="investigation-actions"><Link className="text-link" href="/investigations">View the complete attempt ledger</Link></div></section>
    <section className="section" id="guarantees"><div className="section-heading"><div><span className="eyebrow">Engineering boundaries</span><h2>Claims you can inspect.</h2></div><p>Local correctness checks do not establish production readiness or customer adoption.</p></div>
      <dl className="investigation-boundaries"><div><dt>Saved before acceptance</dt><dd>PostgreSQL commits the request identity before the API returns 202. Reusing the identity with a different command returns a conflict.</dd></div><div><dt>Uncertain calls stay uncertain</dt><dd>Dispatch intent is saved before inference. A crash without a captured response never triggers a silent retry.</dd></div><div><dt>Changes remain isolated</dt><dd>Tools operate on immutable source snapshots and disposable copies. Downloads contain proposed patches; they do not alter your working repository.</dd></div><div><dt>Evaluation has limits</dt><dd>These are six historical cases with human-selected source entry points. Public issues may have appeared in training data. The comparison is descriptive.</dd></div></dl>
      <div className="investigation-actions"><Link className="text-link" href="/engineering">Read the architecture</Link><Link className="text-link" href="/history">Historical synthetic demonstrations</Link></div>
    </section>
  </>;
}
