import { NextRequest, NextResponse } from "next/server";
import { apiBase } from "@/lib/kairos-api";
export async function GET(_request: NextRequest, context: { params: Promise<{ path: string[] }> }) {
  const path = (await context.params).path.join("/");
  if (!/^[a-f0-9-]{36}\/(bundle|patch)$/.test(path)) return NextResponse.json({ error: "Unsupported download." }, { status: 404 });
  try {
    const response = await fetch(apiBase() + "/api/public/investigations/" + path, { cache: "no-store", redirect: "manual", signal: AbortSignal.timeout(10000) });
    const headers = new Headers({ "Content-Type": response.headers.get("content-type") || "application/json", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" });
    const disposition = response.headers.get("content-disposition");
    if (disposition) headers.set("Content-Disposition", disposition);
    return new NextResponse(await response.arrayBuffer(), { status: response.status, headers });
  } catch { return NextResponse.json({ error: "Evidence download unavailable." }, { status: 502 }); }
}
