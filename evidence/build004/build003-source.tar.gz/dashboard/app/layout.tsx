import type { Metadata } from "next";
import Link from "next/link";
import "@fontsource/dm-sans/latin-400.css";
import "@fontsource/dm-sans/latin-500.css";
import "@fontsource/dm-sans/latin-700.css";
import "@fontsource/instrument-serif/latin-400.css";
import "@fontsource/instrument-serif/latin-400-italic.css";
import "./globals.css";
import "./investigations.css";
export const metadata: Metadata = {
  title: {
    default: "Kairos — Inspect the investigation",
    template: "%s — Kairos",
  },
  description:
    "Inspect captured context, investigate agent failures, and test repairs against an independent grader. A full-stack engineering project with inspectable evidence.",
};
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" data-scroll-behavior="smooth">
      <body>
        <a className="skip" href="#main">
          Skip to content
        </a>
        <header className="site-header">
          <Link className="wordmark" href="/" aria-label="Kairos home">
            <span className="brand-symbol" aria-hidden="true">
              κ
            </span>
            Kairos<span className="edition">Build 003</span>
          </Link>
          <nav aria-label="Main navigation">
            <Link href="/investigations">Investigations</Link>
            <Link href="/engineering">Engineering</Link>
            <Link href="/evidence">Evidence</Link>
            <Link href="/reports">Reports</Link>
            <Link href="/history">History</Link>
            <Link href="/workbench">Workbench</Link>
            <Link href="/docs">Docs</Link>
          </nav>
        </header>
        <main id="main">{children}</main>
        <footer className="site-footer">
          <Link className="footer-mark" href="/">
            Kairos
          </Link>
          <p>
            Repository investigations, source changes and independent checks.
            <br />
            <span>
              Real historical cases. Earlier synthetic demonstrations remain labeled.
            </span>
          </p>
          <Link href="/#guarantees">Read the guarantees</Link>
        </footer>
      </body>
    </html>
  );
}
