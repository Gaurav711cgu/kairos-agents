import { getInvestigations } from "@/lib/investigations";
import { InvestigationRows } from "@/components/InvestigationRows";
import { ServiceError } from "@/components/IncidentRows";
export const dynamic = "force-dynamic";
export default async function Investigations() {
  const result = await getInvestigations();
  return <div className="page-shell">
    <header className="page-heading"><span className="eyebrow">Real repository cases</span><h1>Every attempt.<br /><em>Open to inspection.</em></h1>
      <p>Historical defects in Kairos and Django. Actual local model responses, proposed patches and independent checks.</p>
    </header>
    <p className="investigation-scope">Six human-localized cases. A descriptive comparison, with failed attempts included. Public issues may appear in model training data.</p>
    {!result.data ? <ServiceError message={result.error} /> : <InvestigationRows records={result.data.investigations} />}
  </div>;
}
