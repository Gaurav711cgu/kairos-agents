import Link from "next/link";
import { isFrozenComparison, getInvestigation, getInvestigations, caseTitle, configurationLabel } from "@/lib/investigations";
import { InvestigationInspector } from "@/components/InvestigationInspector";
import { ServiceError } from "@/components/IncidentRows";
export const dynamic = "force-dynamic";
export default async function InvestigationPage({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ step?: string }> }) {
  const { id } = await params;
  const result = await getInvestigation(id);
  if (!result.data) return <div className="page-shell"><Link className="text-link" href="/investigations">All investigations</Link><ServiceError message={result.error} /></div>;
  const record = result.data;
  const listing = await getInvestigations();
  const peer = listing.data?.investigations.find(item => (!isFrozenComparison(record) || isFrozenComparison(item)) && item.task_id === record.task_id && item.configuration !== record.configuration && item.configuration.slice(-2) === record.configuration.slice(-2));
  const comparison = peer ? await getInvestigation(peer.id) : null;
  return <div className="page-shell"><Link className="text-link" href="/investigations">All investigations</Link>
    <header className="page-heading investigation-heading"><span className="eyebrow">{record.task_snapshot.repository} / {configurationLabel(record.configuration)}</span><h1>{caseTitle(record.task_id, record.task_snapshot.title)}</h1><p>Historical source. Actual model attempt. Independent verification.</p></header>
    <InvestigationInspector record={record} comparison={comparison?.data ?? null} initialStep={Number((await searchParams).step) || 0} />
  </div>;
}
