import Link from "next/link";

export const metadata = { title: "Reproduction and contracts" };

const setup = [
  "# Repository root; Python 3.12+, Node.js 24 and Docker required",
  "python3 -m venv .venv",
  ".venv/bin/python -m pip install -r requirements-api.lock",
  "python3 scripts/configure_local.py",
  "docker compose --env-file .env.kairos.local up -d --wait",
  "python3 scripts/run_local.py seed",
  "npm --prefix dashboard ci",
];
const services = [
  "# Separate terminals, each from repository root",
  "python3 scripts/run_local.py api      # 127.0.0.1:8100",
  "python3 scripts/run_local.py web      # 127.0.0.1:3100",
  "python3 scripts/run_local.py investigator # bounded repository investigations",
  "python3 scripts/setup_investigation_runtime.py --serve # Qwen3 on :8130",
];
const decisions = [
  {
    title: "PostgreSQL owns the durable boundary",
    body: "Commit receipts before acknowledgement. Use short transactions for reference runs, and durable worker intents for slow calls. A memory buffer is insufficient; the Go prototype is outside the active path.",
  },
  {
    title: "A model response is evidence, not authority",
    body: "Capture the rendered request and unmodified response. Validate strict JSON, evidence citations and policy semantics independently. Calculate cents with a deterministic tool.",
  },
  {
    title: "Unknown means no automatic redispatch",
    body: "Worker fencing blocks stale commits. A dispatch without a durable response becomes unknown. Continue only from a known captured result or create a distinct fresh fork.",
  },
  {
    title: "A release can be inconclusive",
    body: "Use a fixed paired Hoeffding bound, alpha 0.05, margin 0.10 and 1,024 predeclared synthetic holdout tasks. Hard invariants block; small samples do not establish noninferiority.",
  },
];
export default function Docs() {
  return (
    <div className="page-shell reading-page">
      <div className="page-heading">
        <span className="eyebrow">Documentation / Reproduce the boundary</span>
        <h1>
          Run Kairos locally.
          <br />
          <em>Check the implementation.</em>
        </h1>
        <p>
          Start with a real repository investigation. Download its evidence, reproduce candidate checks, and inspect the bounded worker.
        </p>
      </div>
      <div className="article-layout">
        <aside className="article-index">
          <span className="eyebrow">Contents</span>
          <a href="#repair">Reproduce a real repair</a>
          <a href="#setup">Local setup</a>
          <a href="#identity">Identity and model setup</a>
          <a href="#decisions">Design decisions</a>
          <a href="#api">API surface</a>
          <a href="#checks">Checks and limits</a>
        </aside>
        <article className="prose">
          <section id="repair">
            <h2>Recheck the recorded Django repair.</h2>
            <p>After preparing the frozen cases, this command checks the recorded model patch in a fresh source copy and network-disabled container. It does not call the model or database.</p>
            <pre>{["PYTHONPATH=. .venv/bin/python scripts/reproduce_investigation.py", "  --record evidence/build003/django__django-10914-baseline-v3.json", "  --output /tmp/kairos-repair.json"].join(" ")}</pre>
            <p>The candidate changes the default upload permission to 0o644. The selected upstream suite runs 110 tests with one upstream skip. Both the single call and loop made this repair; the loop did not solve additional cases.</p>
          </section>
          <section id="setup">
            <h2>Run the connected application.</h2>
            <p>
              These commands start the FastAPI and PostgreSQL product path.
              Configuration generates ignored local credentials once. Keep ports
              55432, 8100 and 3100 free; do not start a second database over an
              existing instance.
            </p>
            <pre>{setup.join("\n")}</pre>
            <pre>{services.join("\n")}</pre>
            <p>
              Open <code>http://127.0.0.1:3100</code>. Public records require
              the API. The site shows an unavailable state when the service
              cannot be reached.
            </p>
          </section>
          <section id="identity">
            <h2>Provision local identity separately.</h2>
            <p>
              The repository includes a real local Keycloak OIDC integration. It
              uses synthetic accounts and PostgreSQL membership, not a public
              demo password. From the locked API environment:
            </p>
            <pre>
              {[
                "KAIROS_IDENTITY_PREPARE_ONLY=1 PYTHONPATH=. .venv/bin/python scripts/setup_identity.py",
                "docker run -d --name kairos-keycloak --env-file .runtime/keycloak-bootstrap.env -p 127.0.0.1:8088:8080 -v kairos_keycloak:/opt/keycloak/data quay.io/keycloak/keycloak:26.8.0 start-dev --http-port=8080 --hostname=http://127.0.0.1:8088",
                "PYTHONPATH=. .venv/bin/python scripts/setup_identity.py",
                "# Restart the API to load .runtime/identity.env",
              ].join("\n")}
            </pre>
            <p>
              If this project already has a provider on port 8088, reuse it.
              Synthetic credentials live in{" "}
              <code>.runtime/identity.local.json</code>; do not publish that
              file. Detailed provider checks and deployment limits are in{" "}
              <code>infra/identity/README.md</code>.
            </p>
            <p>The investigation runtime uses official Qwen3-1.7B-GGUF Q8_0 and a pinned llama.cpp binary. The installer supports macOS ARM64. Keep at least 4 GiB free and avoid heavy frontend builds during inference.</p>
            <pre>{[".venv/bin/python scripts/setup_investigation_runtime.py", "docker build -f Dockerfile.investigation-django -t kairos-investigation-django:build003 .", "PYTHONPATH=. .venv/bin/python scripts/prepare_investigation_cases.py"].join("\n")}</pre>
            <p>Case preparation also requires the historical API image identified in the frozen registry. Follow the README historical-image recipe on a clean machine. Existing installations should reuse frozen image IDs.</p>
            <p>
              <code>KAIROS_MODEL_ENDPOINT</code> selects the model endpoint.{" "}
              <code>KAIROS_BLOB_DIR</code> selects fsynced local blob storage.
              Production requires HTTPS identity URLs, Secure cookies, protected
              secret injection and a production-mode provider. The local
              provider command uses development mode.
            </p>
          </section>
          <section id="decisions">
            <h2>Design decisions</h2>
            <div className="space-y-4 not-prose">
              {decisions.map((decision, index) => (
                <div className="antigravity-card p-5" key={decision.title}>
                  <span className="eyebrow">
                    Decision {String(index + 1).padStart(2, "0")}
                  </span>
                  <h3 className="text-base font-semibold my-2">
                    {decision.title}
                  </h3>
                  <p className="text-sm text-zinc-400">{decision.body}</p>
                </div>
              ))}
            </div>
          </section>
          <section id="api">
            <h2>Public and authenticated APIs</h2>
            <div className="endpoint-list">
              <code>GET /api/public/investigations · GET /api/public/investigations/:id</code><p>Published source provenance, captured steps, independent results and evidence downloads.</p>
              <code>POST /api/investigations · POST /api/investigations/:id/cancel · POST /api/investigations/:id/fork</code><p>Authenticated registered-case commands. Replay reads stored captures; publication requires an administrator.</p>
              <code>
                GET /api/public/incidents · GET /api/public/incidents/:id
              </code>
              <p>
                Published reference runs, context, ordered events, independent
                grade and fresh-fork lineage.
              </p>
              <code>GET /api/public/jobs · GET /api/public/jobs/:id</code>
              <p>
                Published durable jobs with captured model requests, responses,
                state and recovery events.
              </p>
              <code>
                GET /api/public/evaluations · GET /api/public/evaluations/:id
              </code>
              <p>
                Published evaluation reports with task rows, hard checks,
                interval and declared scope.
              </p>
              <code>
                POST /api/jobs · POST /api/jobs/:id/cancel · POST
                /api/jobs/:id/recover
              </code>
              <p>
                Authenticated, tenant-scoped job commands. Creation requires an
                idempotency key. Recovery supports a known captured result, not
                arbitrary time travel.
              </p>
              <code>
                GET /api/auth/me · GET /api/auth/login · POST /api/auth/logout
              </code>
              <p>
                Server session identity, OIDC sign-in and local session
                revocation. Browser tokens are not exposed.
              </p>
            </div>
          </section>
          <section id="checks">
            <h2>Run the verification checks</h2>
            <pre>
              {[
                "python3 scripts/run_local.py test",
                "npm --prefix dashboard run lint",
                "cd dashboard && npx tsc --noEmit && npm run build",
              ].join("\n")}
            </pre>
            <p>
              PostgreSQL integration tests need <code>TEST_DATABASE_URL</code>{" "}
              and use isolated temporary schemas. Provider tests need the local
              Keycloak setup. The active API lock is{" "}
              <code>requirements-api.lock</code>; legacy Go and harness tests
              are not part of product qualification.
            </p>
            <aside className="scope-note">
              <strong>Current evidence boundary</strong>
              <p>
                Six real historical cases use human-selected source entry points. Both approaches repaired one case. Earlier synthetic tasks and failed model jobs remain historical evidence. This is neither a SWE-bench leaderboard submission nor model research. Hosting and outside-user adoption remain unverified.
              </p>
            </aside>
            <Link className="text-link" href="/engineering">
              Read the engineering rationale
            </Link>
          </section>
        </article>
      </div>
    </div>
  );
}
