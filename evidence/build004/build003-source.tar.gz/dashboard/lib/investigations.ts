import cohort from "./investigation-cohort.json";
import { z } from "zod";
import { apiBase, type ApiResult } from "@/lib/kairos-api";

export const investigationSummary = z.object({
  id: z.string(), task_id: z.string(), title: z.string(), configuration: z.string(),
  status: z.string(), outcome: z.string().nullable(), summary: z.string().nullable(),
  created_at: z.string(), updated_at: z.string(), model_calls: z.number(),
  patch_count: z.number(), check_count: z.number(), parent_id: z.string().nullable(), published: z.boolean(),
});
const capture = z.object({ sha256: z.string(), body: z.record(z.string(), z.unknown()) });
export const investigationSchema = z.object({
  id: z.string(), task_id: z.string(), configuration: z.string(), status: z.string(),
  outcome: z.string().nullable(), summary: z.string().nullable(), model_calls: z.number(),
  patch_count: z.number(), check_count: z.number(), created_at: z.string(), updated_at: z.string(),
  started_at: z.string().nullable(), deadline_at: z.string().nullable(), published: z.boolean(),
  parent_id: z.string().nullable(), task_digest: z.string(),
  task_snapshot: z.object({ title: z.string(), issue: z.string(), repository: z.string(),
    revision: z.string(), issue_url: z.string().nullable(), source_url: z.string(),
    source_digest: z.string(), split: z.string(), provenance: z.string(), entry_files: z.array(z.string()),
    qualified: z.boolean(), command: z.array(z.string()), image: z.string(),
  }),
  config_snapshot: z.record(z.string(), z.unknown()),
  steps: z.array(z.object({ seq: z.number(), kind: z.string(), name: z.string(), state: z.string(),
    request: capture, result: capture.nullable(), started_at: z.string(), captured_at: z.string().nullable(),
  })),
  artifacts: z.array(z.object({ sha256: z.string(), bytes: z.number() })),
  integrity: z.object({ verified: z.boolean(), scope: z.string() }),
});
export type Investigation = z.infer<typeof investigationSchema>;
export type InvestigationSummary = z.infer<typeof investigationSummary>;
export const outcomeLabel = (outcome: string | null, status = "") => ({
  verified_repair: "Verified repair", failed_checks: "Checks failed", invalid_patch: "Patch rejected",
  no_patch: "No patch proposed", invalid_response: "Invalid model response", unknown_dispatch: "Dispatch outcome unknown",
  environment_failure: "Environment failure", timeout: "Time limit reached", cancelled: "Cancelled",
  claim_budget_exhausted: "Recovery limit reached",
}[outcome ?? ""] || ({ queued: "Queued", running: "Running" }[status] ?? "Outcome pending"));
export const configurationLabel = (configuration: string) => configuration.startsWith("baseline-") ? "Single call" : "Tool loop";

const get = async <T>(path: string, schema: z.ZodType<T>): Promise<ApiResult<T>> => {
  try {
    const response = await fetch(apiBase() + path, { cache: "no-store", signal: AbortSignal.timeout(10000) });
    if (!response.ok) return { data: null, error: `Investigation service returned HTTP ${response.status}.` };
    const result = schema.safeParse(await response.json());
    if (!result.success) return { data: null, error: "Unsupported investigation record. No unverified data is shown." };
    return { data: result.data, error: null };
  } catch { return { data: null, error: "Investigation service unavailable. Recorded evidence will appear when it returns." }; }
};
export const getInvestigations = () => get("/api/public/investigations", z.object({ investigations: z.array(investigationSummary) }));
export const getInvestigation = (id: string) => get("/api/public/investigations/" + encodeURIComponent(id), investigationSchema);
export const modelUsage = (record: Investigation) => record.steps.reduce((total, step) => {
  if (step.kind !== "model" || !step.result) return total;
  const usage = step.result.body.usage;
  if (typeof usage !== "object" || !usage) return total;
  const value = usage as Record<string, unknown>;
  return total + (typeof value.prompt_tokens === "number" ? value.prompt_tokens : 0) + (typeof value.completion_tokens === "number" ? value.completion_tokens : 0);
}, 0);
export const elapsed = (record: Investigation) => record.started_at ? Math.max(0, Math.round((Date.parse(record.updated_at) - Date.parse(record.started_at)) / 1000)) : null;

// Editorial labels only; the captured issue and model input remain unchanged.
export const caseTitle = (id: string, fallback: string) => ({
  "kairos-clock-lease": "Clock skew breaks worker lease checks",
  "kairos-body-limit": "Oversized commands reach JSON parsing",
  "django__django-10554": "Ordering a union changes its selected columns",
  "django__django-10880": "Distinct counts generate invalid SQL",
  "django__django-10914": "Uploaded files receive inconsistent permissions",
  "django__django-10973": "Pass database shell credentials through a scoped environment",
}[id] || fallback);

const frozenIds = new Set(cohort.ids);
export const isFrozenComparison = (record: { id: string }) => frozenIds.has(record.id);
