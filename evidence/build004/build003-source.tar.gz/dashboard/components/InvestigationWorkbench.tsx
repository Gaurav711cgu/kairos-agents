"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { z } from "zod";
import { investigationSchema, investigationSummary, outcomeLabel, caseTitle, configurationLabel, type Investigation, type InvestigationSummary } from "@/lib/investigations";
const caseSchema = z.object({ id: z.string(), title: z.string(), qualified: z.boolean(), split: z.string() });
async function command(path: string, body?: unknown, key?: string) {
  const response = await fetch("/api/workbench/investigations" + path, { method: body === undefined ? "GET" : "POST", headers: { "Content-Type": "application/json", ...(key ? { "Idempotency-Key": key } : {}) }, body: body === undefined ? undefined : JSON.stringify(body) });
  const value = await response.json();
  if (!response.ok) throw new Error(value.detail || value.error || "Investigation request failed.");
  return value;
}
export function InvestigationWorkbench({ role, workspace }: { role: string; workspace: string }) {
  const [cases, setCases] = useState<z.infer<typeof caseSchema>[]>([]);
  const [records, setRecords] = useState<InvestigationSummary[]>([]);
  const [task, setTask] = useState("");
  const [configuration, setConfiguration] = useState("loop-v3");
  const [selected, setSelected] = useState<Investigation | null>(null);
  const [playback, setPlayback] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const pending = useRef<{ digest: string; key: string } | null>(null);
  const refresh = useCallback(async () => {
    try {
      const [caseList, listing] = await Promise.all([command("/cases"), command("")]);
      const registered = z.object({ cases: z.array(caseSchema) }).parse(caseList).cases.filter(item => item.qualified);
      setCases(registered);setTask(previous => previous || registered[0]?.id || "");
      setRecords(z.object({ investigations: z.array(investigationSummary) }).parse(listing).investigations);setLoaded(true);setError("");
    } catch (failure) { setError(failure instanceof Error ? failure.message : "Investigation records unavailable."); }
  }, []);
  useEffect(() => { const timer = setTimeout(() => { void refresh(); }, 0); return () => clearTimeout(timer); }, [refresh]);
  const submit = async () => {
    setBusy(true);setError("");
    const body = { task_id: task, configuration };
    const digest = JSON.stringify(body);
    if (!pending.current || pending.current.digest !== digest) pending.current = { digest, key: crypto.randomUUID() };
    try { setPlayback(false);setSelected(investigationSchema.parse(await command("", body, pending.current.key)));pending.current=null;await refresh(); }
    catch (failure) { setError(failure instanceof Error ? failure.message : "Submission failed. Retry the same command to reuse its identity."); }
    finally { setBusy(false); }
  };
  const inspect = async (id: string) => { try { setSelected(investigationSchema.parse(await command("/"+id)));setError(""); } catch (failure) { setError(failure instanceof Error ? failure.message : "Record unavailable."); } };
  const replay = async () => {
    if (!selected) return;
    try { const value = await command("/"+selected.id+"/replay");setSelected(investigationSchema.parse(value.investigation));setPlayback(true);setError(""); }
    catch (failure) { setError(failure instanceof Error ? failure.message : "Playback unavailable."); }
  };
  const signOut = async () => {
    try { const result = await fetch("/api/workbench/auth/logout", {method:"POST",headers:{"Content-Type":"application/json"},body:"{}"});if (!result.ok) throw new Error("Sign out failed.");window.location.assign("/workbench"); }
    catch (failure) {setError(failure instanceof Error ? failure.message : "Sign out unavailable.");}
  };
  const mutate = async (operation: string) => {
    if (!selected) return;
    setBusy(true);
    try {
      const result = await command("/"+selected.id+"/"+operation, operation==="fork" ? { configuration } : {}, operation==="fork" ? crypto.randomUUID() : undefined);
      setPlayback(false);setSelected(investigationSchema.parse(result));await refresh();
    } catch (failure) { setError(failure instanceof Error ? failure.message : "Operation failed."); }
    finally { setBusy(false); }
  };
  return <section className="investigation-workbench">
    <div className="investigation-actions"><span>Workspace {workspace} · {role.charAt(0).toUpperCase()+role.slice(1)}</span><button className="button dark" onClick={signOut}>Sign out</button></div>
    <header><span className="eyebrow">Registered repository cases</span><h2>Start an investigation.</h2><p>Private by default. Six calls maximum. Source changes stay in a disposable copy.</p></header>
    {error && <p role="alert" className="error-state">{error}</p>}
    <div className="investigation-filters">
      <label>Historical case<select value={task} onChange={event=>setTask(event.target.value)} disabled={!loaded || busy}>{cases.map(item=><option key={item.id} value={item.id}>{caseTitle(item.id, item.title)} · {item.split}</option>)}</select></label>
      <label>Approach<select value={configuration} onChange={event=>setConfiguration(event.target.value)} disabled={busy}><option value="loop-v3">Tool loop · Up to six calls</option><option value="baseline-v3">Single-call baseline</option></select></label>
      <button className="button primary" disabled={!task || busy || role==="viewer"} onClick={submit}>{busy ? "Saving command…" : "Queue investigation"}</button>
      <button className="button dark" onClick={refresh} disabled={busy}>Refresh records</button>
    </div>
    {loaded && !cases.length && <p>No cases have passed preflight. Prepare and verify the registered cases first.</p>}
    <p className="investigation-scope">Validation cases are locked evaluation material. An interactive rerun is a new attempt, not an untouched holdout result.</p>
    <div className="private-investigation-list">{records.map(item=><button key={item.id} onClick={()=>inspect(item.id)} aria-pressed={selected?.id===item.id}><span>{caseTitle(item.task_id, item.title)}</span><small>{configurationLabel(item.configuration)} · {outcomeLabel(item.outcome,item.status)}</small></button>)}</div>
    {selected && <div className="private-investigation-detail"><h3>{caseTitle(selected.task_id, selected.task_snapshot.title)}</h3><p aria-live="polite">{outcomeLabel(selected.outcome,selected.status)} · {selected.model_calls} model {selected.model_calls === 1 ? "call" : "calls"} · {selected.check_count} check {selected.check_count === 1 ? "run" : "runs"}</p>
      {playback && <p role="status">Recorded playback. No model calls or tool execution.</p>}
      <div className="investigation-actions"><button className="button dark" disabled={busy} onClick={replay}>Replay saved steps</button><button className="button dark" disabled={busy} onClick={()=>inspect(selected.id)}>Refresh this attempt</button><button className="button dark" disabled={busy || role==="viewer" || !["queued","running"].includes(selected.status)} onClick={()=>mutate("cancel")}>Cancel</button><button className="button dark" disabled={busy || role==="viewer"} onClick={()=>mutate("fork")}>Create a fresh fork</button>{role==="admin" && <button className="button dark" disabled={busy || ["queued","running"].includes(selected.status) || selected.published} onClick={()=>mutate("publish")}>Publish evidence</button>}</div>
      <details className="raw-record"><summary>Captured record and patch</summary><textarea readOnly aria-label="Private investigation record" value={JSON.stringify(selected,null,2)} /></details>
    </div>}
  </section>;
}
